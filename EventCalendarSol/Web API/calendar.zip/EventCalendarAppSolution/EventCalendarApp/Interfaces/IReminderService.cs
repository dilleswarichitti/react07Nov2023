﻿//using EventCalendarApp.Models;
//using System.Security.Cryptography;

//namespace EventCalendarApp.Interfaces
//{
//    public interface IReminderService
//    {
//        List<Reminder> GetReminders();
//        Reminder Add(Reminder reminders);
//        //Reminder Remove(Reminder reminders);
//        //Reminder Update(Reminder reminders);
//    }
//}