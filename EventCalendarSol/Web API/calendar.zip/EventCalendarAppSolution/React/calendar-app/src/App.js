import logo from './logo.svg';
import './App.css';
import ShareEvent from './components/ShareEvent';

function App() {
  return (
    <div className="App">
      <div>
        <ShareEvent/>
      </div>
    </div>
);
}

export default App;