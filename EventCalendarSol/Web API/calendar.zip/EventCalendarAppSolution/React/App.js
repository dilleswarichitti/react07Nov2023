import logo from './logo.svg';
import './App.css';
import AddEvent from './components/AddEvent';

function App() {
  return (
    <div className="App">
      <AddEvent/>
    </div>
  );
}

export default App;
